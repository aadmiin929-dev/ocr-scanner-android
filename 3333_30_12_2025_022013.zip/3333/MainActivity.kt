package com.example.ocrscanner

import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider

class MainActivity : AppCompatActivity() {

    private fun processPdf(uri: Uri) {
    val descriptor: ParcelFileDescriptor =
        contentResolver.openFileDescriptor(uri, "r") ?: return

    val renderer = PdfRenderer(descriptor)
    val textResult = StringBuilder()

    for (i in 0 until renderer.pageCount) {
        val page = renderer.openPage(i)

        val bitmap = Bitmap.createBitmap(
            page.width,
            page.height,
            Bitmap.Config.ARGB_8888
        )

        page.render(
            bitmap,
            null,
            null,
            PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
        )

        page.close()

        OcrHelper.recognize(bitmap) {
            textResult.append(it).append("\n\n")
            result.text = textResult.toString()
        }
    }

    renderer.close()
    descriptor.close()
}

findViewById<Button>(R.id.btnPdf).setOnClickListener {
    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
    intent.type = "application/pdf"
    pdfLauncher.launch(intent)
}
    private val pdfLauncher =
    registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) {
            val uri = it.data?.data ?: return@registerForActivityResult
            processPdf(uri)
        }
    }

    private lateinit var result: TextView

    private val camera =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                val bmp = it.data?.extras?.get("data") as Bitmap
                OcrHelper.recognize(bmp) { result.text = it }
            }
        }

    private val gallery =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                val uri: Uri = it.data?.data!!
                val bmp = ImageDecoder.decodeBitmap(
                    ImageDecoder.createSource(contentResolver, uri))
                OcrHelper.recognize(bmp) { result.text = it }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        result = findViewById(R.id.txtResult)

        findViewById<Button>(R.id.btnCamera).setOnClickListener {
            camera.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        }

        findViewById<Button>(R.id.btnGallery).setOnClickListener {
            gallery.launch(Intent(Intent.ACTION_PICK).apply { type = "image/*" })
        }

        findViewById<Button>(R.id.btnExport).setOnClickListener {
            val file = ExportHelper.export(this, result.text.toString())
            val uri = FileProvider.getUriForFile(
                this, "$packageName.provider", file)
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                "Поделиться"
            ))
        }
    }
}