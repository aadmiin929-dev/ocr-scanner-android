package com.example.ocrscanner

import android.content.Context
import org.json.JSONObject
import java.io.File

object ExportHelper {
    fun export(context: Context, text: String): File {
        val file = File(context.filesDir, "result.txt")
        file.writeText(text)
        return file
    }
}